import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { 
  createUserProfile, 
  getUserProfile, 
  updateLastLogin,
  userProfileExists,
  UserProfile, 
  CreateUserProfileData,
  updateUserProfile as updateFirestoreProfile
} from '@/lib/firestore';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, displayName?: string, additionalData?: Partial<CreateUserProfileData>) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  updateUserProfile: (displayName: string) => Promise<void>;
  refreshUserProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const login = async (email: string, password: string): Promise<void> => {
    try {
      const { user } = await signInWithEmailAndPassword(auth, email, password);
      
      // Update last login timestamp
      await updateLastLogin(user.uid);
      
      // Load user profile
      const profile = await getUserProfile(user.uid);
      setUserProfile(profile);
    } catch (error) {
      throw error;
    }
  };

  const register = async (
    email: string, 
    password: string, 
    displayName?: string,
    additionalData?: Partial<CreateUserProfileData>
  ): Promise<void> => {
    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, password);
      
      // Update Firebase Auth profile
      if (displayName && user) {
        await updateProfile(user, { displayName });
      }

      // Create Firestore user profile
      const profileData: CreateUserProfileData = {
        email: user.email || email,
        displayName: displayName || user.displayName || email.split('@')[0],
        role: additionalData?.role || 'admin',
        schoolName: additionalData?.schoolName || localStorage.getItem('school_name') || 'SmartSchool',
        phoneNumber: additionalData?.phoneNumber
      };

      const profile = await createUserProfile(user, profileData);
      setUserProfile(profile);
    } catch (error) {
      throw error;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await signOut(auth);
      setUserProfile(null);
    } catch (error) {
      throw error;
    }
  };

  const resetPassword = async (email: string): Promise<void> => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      throw error;
    }
  };

  const loginWithGoogle = async (): Promise<void> => {
    try {
      const provider = new GoogleAuthProvider();
      const { user } = await signInWithPopup(auth, provider);
      
      // Check if user profile exists
      const profileExists = await userProfileExists(user.uid);
      
      if (!profileExists) {
        // Create profile for new Google user
        const profileData: CreateUserProfileData = {
          email: user.email || '',
          displayName: user.displayName || user.email?.split('@')[0] || 'User',
          role: 'admin',
          schoolName: localStorage.getItem('school_name') || 'SmartSchool'
        };
        
        const profile = await createUserProfile(user, profileData);
        setUserProfile(profile);
      } else {
        // Load existing profile and update last login
        await updateLastLogin(user.uid);
        const profile = await getUserProfile(user.uid);
        setUserProfile(profile);
      }
    } catch (error) {
      throw error;
    }
  };

  const updateUserProfile = async (displayName: string): Promise<void> => {
    try {
      if (currentUser) {
        await updateProfile(currentUser, { displayName });
        
        // Also update Firestore profile
        if (userProfile) {
          await updateFirestoreProfile(currentUser.uid, { displayName });
          
          // Refresh profile data
          await refreshUserProfile();
        }
      }
    } catch (error) {
      throw error;
    }
  };

  const refreshUserProfile = async (): Promise<void> => {
    if (currentUser) {
      const profile = await getUserProfile(currentUser.uid);
      setUserProfile(profile);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      
      if (user) {
        // Load user profile from Firestore
        const profile = await getUserProfile(user.uid);
        setUserProfile(profile);
        
        // If profile doesn't exist, create it (for existing users)
        if (!profile) {
          try {
            const profileData: CreateUserProfileData = {
              email: user.email || '',
              displayName: user.displayName || user.email?.split('@')[0] || 'User',
              role: 'admin',
              schoolName: localStorage.getItem('school_name') || 'SmartSchool'
            };
            
            const newProfile = await createUserProfile(user, profileData);
            setUserProfile(newProfile);
          } catch (error) {
            console.error('Error creating user profile:', error);
          }
        }
      } else {
        setUserProfile(null);
      }
      
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value: AuthContextType = {
    currentUser,
    userProfile,
    loading,
    login,
    register,
    logout,
    resetPassword,
    loginWithGoogle,
    updateUserProfile,
    refreshUserProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
