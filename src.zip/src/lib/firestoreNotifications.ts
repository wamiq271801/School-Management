import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  setDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  Timestamp,
  serverTimestamp,
  limit,
  arrayUnion,
} from "firebase/firestore";
import { db } from "./firebase";

// ============= NOTIFICATIONS INTERFACES =============

export interface Notification {
  id: string;
  type: "system" | "announcement" | "private" | "fee" | "exam" | "attendance";
  title: string;
  message: string;
  recipientId?: string; // For private messages, undefined for announcements
  recipientType?: "student" | "teacher" | "all";
  attachmentUrl?: string;
  attachmentName?: string;
  readBy: string[]; // Array of user IDs who have read this notification
  priority: "low" | "medium" | "high";
  createdBy?: string;
  createdAt: string;
  expiresAt?: string; // Optional expiry date for notifications
}

export interface NotificationPreferences {
  userId: string;
  feeDueReminders: boolean;
  examAlerts: boolean;
  attendanceAlerts: boolean;
  announcementAlerts: boolean;
}

// ============= NOTIFICATION CRUD OPERATIONS =============

export async function createNotification(
  notificationData: Omit<Notification, "id" | "createdAt" | "readBy">
): Promise<string> {
  const docRef = await addDoc(collection(db, "notifications"), {
    ...notificationData,
    readBy: [],
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function deleteNotification(notificationId: string): Promise<void> {
  const docRef = doc(db, "notifications", notificationId);
  await deleteDoc(docRef);
}

export async function markNotificationAsRead(notificationId: string, userId: string): Promise<void> {
  const docRef = doc(db, "notifications", notificationId);
  await updateDoc(docRef, {
    readBy: arrayUnion(userId),
  });
}

export async function getNotifications(filters?: {
  recipientId?: string;
  type?: string;
  limit?: number;
}): Promise<Notification[]> {
  let q = query(collection(db, "notifications"), orderBy("createdAt", "desc"));

  if (filters?.type) {
    q = query(q, where("type", "==", filters.type));
  }

  if (filters?.limit) {
    q = query(q, limit(filters.limit));
  }

  const snapshot = await getDocs(q);
  let notifications = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Notification));

  // Filter by recipient after fetching (since we need OR logic)
  if (filters?.recipientId) {
    notifications = notifications.filter(
      (notif) =>
        !notif.recipientId || // Announcements (no specific recipient)
        notif.recipientId === filters.recipientId || // Direct message to user
        notif.recipientType === "all" // Broadcast to all
    );
  }

  return notifications;
}

export async function getUnreadCount(userId: string): Promise<number> {
  const notifications = await getNotifications({ recipientId: userId });
  return notifications.filter((n) => !n.readBy.includes(userId)).length;
}

export function subscribeToNotifications(
  userId: string,
  callback: (notifications: Notification[]) => void
): () => void {
  const q = query(collection(db, "notifications"), orderBy("createdAt", "desc"), limit(50));

  return onSnapshot(q, (snapshot) => {
    let notifications = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Notification));
    
    // Filter for user-specific notifications
    notifications = notifications.filter(
      (notif) =>
        !notif.recipientId || // Announcements
        notif.recipientId === userId || // Direct message
        notif.recipientType === "all" // Broadcast
    );
    
    callback(notifications);
  });
}

export function subscribeToUnreadCount(
  userId: string,
  callback: (count: number) => void
): () => void {
  const q = query(collection(db, "notifications"), orderBy("createdAt", "desc"), limit(50));

  return onSnapshot(q, (snapshot) => {
    let notifications = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Notification));
    
    // Filter for user-specific notifications
    notifications = notifications.filter(
      (notif) =>
        !notif.recipientId || 
        notif.recipientId === userId || 
        notif.recipientType === "all"
    );
    
    const unreadCount = notifications.filter((n) => !n.readBy.includes(userId)).length;
    callback(unreadCount);
  });
}

// ============= NOTIFICATION PREFERENCES =============

export async function getNotificationPreferences(userId: string): Promise<NotificationPreferences | null> {
  const docRef = doc(db, "notificationPreferences", userId);
  const docSnap = await getDoc(docRef);
  
  if (docSnap.exists()) {
    return docSnap.data() as NotificationPreferences;
  }
  return null;
}

export async function saveNotificationPreferences(
  userId: string,
  preferences: Omit<NotificationPreferences, "userId">
): Promise<void> {
  const docRef = doc(db, "notificationPreferences", userId);
  await updateDoc(docRef, preferences).catch(async () => {
    // If document doesn't exist, create it
    await setDoc(docRef, { userId, ...preferences });
  });
}

// ============= AUTOMATIC NOTIFICATION TRIGGERS =============

export async function triggerFeeOverdueNotification(studentId: string, amountDue: number): Promise<void> {
  await createNotification({
    type: "fee",
    title: "Fee Payment Overdue",
    message: `You have an outstanding fee balance of ₹${amountDue.toLocaleString()}. Please make the payment at the earliest.`,
    recipientId: studentId,
    recipientType: "student",
    priority: "high",
  });
}

export async function triggerExamAddedNotification(
  classId: string,
  examName: string,
  examDate: string
): Promise<void> {
  await createNotification({
    type: "exam",
    title: "New Exam Scheduled",
    message: `${examName} has been scheduled for ${examDate}. Please prepare accordingly.`,
    recipientType: "all",
    priority: "medium",
  });
}

export async function triggerMarksheetReadyNotification(
  studentId: string,
  examName: string,
  driveLink?: string
): Promise<void> {
  await createNotification({
    type: "exam",
    title: "Marksheet Available",
    message: `Your marksheet for ${examName} is now available.`,
    recipientId: studentId,
    recipientType: "student",
    attachmentUrl: driveLink,
    attachmentName: `${examName}_Marksheet.pdf`,
    priority: "medium",
  });
}

export async function triggerAttendanceAlert(studentId: string, attendancePercentage: number): Promise<void> {
  await createNotification({
    type: "attendance",
    title: "Low Attendance Alert",
    message: `Your current attendance is ${attendancePercentage.toFixed(1)}%. Please improve your attendance to meet the minimum requirement.`,
    recipientId: studentId,
    recipientType: "student",
    priority: "high",
  });
}
