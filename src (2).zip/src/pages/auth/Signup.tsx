import React from 'react';
import SignupForm from '@/components/auth/SignupForm';

const Signup: React.FC = () => {
  return <SignupForm />;
};

export default Signup;
