/**
 * Import Service - Connects bulk import to Firebase
 * Handles batch creation, document upload, and student creation
 */

import { collection, addDoc, serverTimestamp, writeBatch, doc } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { createStudent, generateAdmissionNumber, createAuditLog } from '@/lib/firestore';
import { createStorageAdapter, batchUploadDocuments } from './storageAdapter';
import { normalizeToStudentFormat, type ParsedRow } from './importParser';
import { groupMatchesByStudent, type FileMatch } from './zipMatcher';

export interface ImportBatch {
  id: string;
  userId: string;
  userEmail: string;
  fileName: string;
  totalRows: number;
  validRows: number;
  invalidRows: number;
  warningRows: number;
  status: 'pending' | 'reviewing' | 'importing' | 'completed' | 'failed';
  createdAt: any;
  updatedAt: any;
}

export interface ImportRow {
  batchId: string;
  rowNumber: number;
  data: Record<string, any>;
  errors: any[];
  warnings: any[];
  status: 'valid' | 'invalid' | 'warning' | 'imported' | 'failed';
  studentId?: string;
  importedAt?: any;
  errorMessage?: string;
}

/**
 * Create import batch in Firestore
 */
export async function createImportBatch(
  fileName: string,
  rows: ParsedRow[]
): Promise<string> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('User must be authenticated');
  }

  const validRows = rows.filter((r) => r.status === 'valid').length;
  const invalidRows = rows.filter((r) => r.status === 'invalid').length;
  const warningRows = rows.filter((r) => r.status === 'warning').length;

  const batch: Omit<ImportBatch, 'id'> = {
    userId: user.uid,
    userEmail: user.email || '',
    fileName,
    totalRows: rows.length,
    validRows,
    invalidRows,
    warningRows,
    status: 'pending',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  const batchRef = await addDoc(collection(db, 'importBatches'), batch);

  // Save rows to subcollection
  const rowsCollection = collection(db, 'importBatches', batchRef.id, 'rows');
  const firestoreBatch = writeBatch(db);

  rows.forEach((row) => {
    const rowDoc = doc(rowsCollection);
    const importRow: Omit<ImportRow, 'batchId'> = {
      rowNumber: row.rowNumber,
      data: row.data,
      errors: row.errors,
      warnings: row.warnings,
      status: row.status,
    };
    firestoreBatch.set(rowDoc, importRow);
  });

  await firestoreBatch.commit();

  return batchRef.id;
}

/**
 * Commit import - create students from valid rows
 */
export async function commitImport(
  batchId: string,
  rows: ParsedRow[],
  fileMatches?: FileMatch[],
  onProgress?: (current: number, total: number) => void
): Promise<{
  imported: number;
  failed: number;
  errors: Array<{ rowNumber: number; error: string }>;
}> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('User must be authenticated');
  }

  const validRows = rows.filter((r) => r.status === 'valid' || r.status === 'warning');
  const storage = createStorageAdapter();
  const errors: Array<{ rowNumber: number; error: string }> = [];
  let imported = 0;
  let failed = 0;

  // Group file matches by student (by admission number or name)
  const filesByStudent = fileMatches ? groupMatchesByStudent(fileMatches) : new Map();

  for (let i = 0; i < validRows.length; i++) {
    const row = validRows[i];
    
    try {
      // Generate admission number if not provided
      const admissionNumber = row.data.admissionNo || await generateAdmissionNumber();
      
      // Normalize data to Student format
      const studentData = normalizeToStudentFormat(row.data);
      studentData.admissionNumber = admissionNumber;
      studentData.admissionDate = new Date().toISOString().split('T')[0];

      // Upload documents if available
      const studentFiles = filesByStudent.get(row.rowNumber.toString()) || [];
      if (studentFiles.length > 0) {
        const uploadTasks = studentFiles.map((match) => ({
          file: match.file,
          key: `students/${admissionNumber}/${match.documentType || 'document'}_${match.file.name}`,
          metadata: {
            contentType: match.file.type,
            customMetadata: {
              studentId: admissionNumber,
              documentType: match.documentType || 'unknown',
              uploadedBy: user.uid,
            },
          },
        }));

        const uploadResults = await batchUploadDocuments(uploadTasks, storage);

        // Update document references in student data
        uploadResults.forEach((result, idx) => {
          const docType = studentFiles[idx].documentType;
          if (docType && studentData.documents) {
            (studentData.documents as any)[docType] = {
              fileName: studentFiles[idx].file.name,
              url: result.url,
              driveId: result.key,
              size: result.size,
              uploadedAt: result.uploadedAt,
            };
          }
        });
      }

      // Create student in Firestore
      const studentId = await createStudent(studentData);

      // Create audit log
      await createAuditLog({
        action: 'bulk_import_student',
        resourceType: 'student',
        resourceId: studentId,
        userId: user.uid,
        details: {
          batchId,
          rowNumber: row.rowNumber,
          admissionNumber,
        },
      });

      imported++;
    } catch (error: any) {
      console.error(`Failed to import row ${row.rowNumber}:`, error);
      errors.push({
        rowNumber: row.rowNumber,
        error: error.message || 'Unknown error',
      });
      failed++;
    }

    // Report progress
    if (onProgress) {
      onProgress(i + 1, validRows.length);
    }
  }

  // Update batch status
  const batchRef = doc(db, 'importBatches', batchId);
  await writeBatch(db).update(batchRef, {
    status: failed === 0 ? 'completed' : 'failed',
    updatedAt: serverTimestamp(),
  }).commit();

  // Create summary audit log
  await createAuditLog({
    action: 'bulk_import_complete',
    resourceType: 'import_batch',
    resourceId: batchId,
    userId: user.uid,
    details: {
      imported,
      failed,
      totalRows: validRows.length,
      errors: errors.slice(0, 10), // First 10 errors
    },
  });

  return { imported, failed, errors };
}

/**
 * Get import batch by ID
 */
export async function getImportBatch(batchId: string): Promise<ImportBatch | null> {
  // ASSUMPTION: Implement Firestore query
  // This is a placeholder for the actual implementation
  return null;
}

/**
 * Delete import batch
 */
export async function deleteImportBatch(batchId: string): Promise<void> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('User must be authenticated');
  }

  // ASSUMPTION: Delete batch and all rows
  const batchRef = doc(db, 'importBatches', batchId);
  await writeBatch(db).delete(batchRef).commit();

  await createAuditLog({
    action: 'delete_import_batch',
    resourceType: 'import_batch',
    resourceId: batchId,
    userId: user.uid,
  });
}

/**
 * Generate import summary report
 */
export function generateImportSummary(
  imported: number,
  failed: number,
  errors: Array<{ rowNumber: number; error: string }>
): string {
  const total = imported + failed;
  const successRate = total > 0 ? ((imported / total) * 100).toFixed(1) : '0';

  let summary = `Import Summary\n`;
  summary += `==============\n\n`;
  summary += `Total Processed: ${total}\n`;
  summary += `Successfully Imported: ${imported}\n`;
  summary += `Failed: ${failed}\n`;
  summary += `Success Rate: ${successRate}%\n\n`;

  if (errors.length > 0) {
    summary += `Errors:\n`;
    summary += `-------\n`;
    errors.forEach((err) => {
      summary += `Row ${err.rowNumber}: ${err.error}\n`;
    });
  }

  summary += `\nImport completed at: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}\n`;

  return summary;
}
