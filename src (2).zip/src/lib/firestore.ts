import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  setDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  Timestamp,
  serverTimestamp,
  limit,
} from "firebase/firestore";
import { User } from 'firebase/auth';
import { auth, db } from "./firebase";

// User Profile interfaces
export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: 'admin' | 'teacher' | 'staff';
  schoolId?: string;
  schoolName?: string;
  department?: string;
  phoneNumber?: string;
  address?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  emergencyContact?: {
    name: string;
    relationship: string;
    phoneNumber: string;
  };
  preferences?: {
    theme: 'light' | 'dark' | 'system';
    language: string;
    notifications: {
      email: boolean;
      push: boolean;
      sms: boolean;
    };
  };
  permissions?: {
    students: {
      read: boolean;
      write: boolean;
      delete: boolean;
    };
    teachers: {
      read: boolean;
      write: boolean;
      delete: boolean;
    };
    fees: {
      read: boolean;
      write: boolean;
      delete: boolean;
    };
    attendance: {
      read: boolean;
      write: boolean;
      delete: boolean;
    };
    exams: {
      read: boolean;
      write: boolean;
      delete: boolean;
    };
    settings: {
      read: boolean;
      write: boolean;
    };
  };
  createdAt: Date;
  updatedAt: Date;
  lastLoginAt?: Date;
  isActive: boolean;
  isEmailVerified: boolean;
}

export interface CreateUserProfileData {
  email: string;
  displayName: string;
  role?: 'admin' | 'teacher' | 'staff';
  schoolName?: string;
  phoneNumber?: string;
}

export interface UpdateUserProfileData {
  displayName?: string;
  photoURL?: string;
  schoolName?: string;
  department?: string;
  phoneNumber?: string;
  address?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  emergencyContact?: {
    name: string;
    relationship: string;
    phoneNumber: string;
  };
  preferences?: {
    theme: 'light' | 'dark' | 'system';
    language: string;
    notifications: {
      email: boolean;
      push: boolean;
      sms: boolean;
    };
  };
}

// User Profile Service Functions
const USERS_COLLECTION = 'users';

/**
 * Create a new user profile in Firestore
 */
export async function createUserProfile(
  user: User, 
  additionalData: CreateUserProfileData
): Promise<UserProfile> {
  const userRef = doc(db, USERS_COLLECTION, user.uid);
  
  // Default permissions for admin role
  const defaultPermissions = {
    students: { read: true, write: true, delete: true },
    teachers: { read: true, write: true, delete: true },
    fees: { read: true, write: true, delete: true },
    attendance: { read: true, write: true, delete: true },
    exams: { read: true, write: true, delete: true },
    settings: { read: true, write: true }
  };

  // Default preferences
  const defaultPreferences = {
    theme: 'system' as const,
    language: 'en',
    notifications: {
      email: true,
      push: true,
      sms: false
    }
  };

  const userProfile: Omit<UserProfile, 'createdAt' | 'updatedAt' | 'lastLoginAt'> = {
    uid: user.uid,
    email: user.email || additionalData.email,
    displayName: user.displayName || additionalData.displayName,
    role: additionalData.role || 'admin',
    schoolName: additionalData.schoolName || localStorage.getItem('school_name') || 'SmartSchool',
    permissions: defaultPermissions,
    preferences: defaultPreferences,
    isActive: true,
    isEmailVerified: user.emailVerified
  };

  // Add optional fields only if they have values
  if (user.photoURL) {
    (userProfile as any).photoURL = user.photoURL;
  }
  if (additionalData.phoneNumber) {
    (userProfile as any).phoneNumber = additionalData.phoneNumber;
  }

  const profileWithTimestamps = {
    ...userProfile,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    lastLoginAt: serverTimestamp()
  };

  await setDoc(userRef, profileWithTimestamps);
  
  // Return the profile with current timestamp (approximate)
  return {
    ...userProfile,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastLoginAt: new Date()
  };
}

/**
 * Get user profile from Firestore
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      const data = userSnap.data();
      return {
        ...data,
        createdAt: data.createdAt?.toDate() || new Date(),
        updatedAt: data.updatedAt?.toDate() || new Date(),
        lastLoginAt: data.lastLoginAt?.toDate() || undefined
      } as UserProfile;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
}

/**
 * Update user profile in Firestore
 */
export async function updateUserProfile(
  uid: string, 
  updates: UpdateUserProfileData
): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    
    // Filter out undefined values
    const filteredUpdates = Object.entries(updates).reduce((acc, [key, value]) => {
      if (value !== undefined) {
        acc[key] = value;
      }
      return acc;
    }, {} as any);
    
    await updateDoc(userRef, {
      ...filteredUpdates,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating user profile:', error);
    throw error;
  }
}

/**
 * Update last login timestamp
 */
export async function updateLastLogin(uid: string): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    await updateDoc(userRef, {
      lastLoginAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating last login:', error);
    // Don't throw error for login timestamp update
  }
}

/**
 * Check if user profile exists
 */
export async function userProfileExists(uid: string): Promise<boolean> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    const userSnap = await getDoc(userRef);
    return userSnap.exists();
  } catch (error) {
    console.error('Error checking user profile existence:', error);
    return false;
  }
}

/**
 * Get user by email (for admin purposes)
 */
export async function getUserByEmail(email: string): Promise<UserProfile | null> {
  try {
    const usersRef = collection(db, USERS_COLLECTION);
    const q = query(usersRef, where('email', '==', email));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      const doc = querySnapshot.docs[0];
      const data = doc.data();
      return {
        ...data,
        createdAt: data.createdAt?.toDate() || new Date(),
        updatedAt: data.updatedAt?.toDate() || new Date(),
        lastLoginAt: data.lastLoginAt?.toDate() || undefined
      } as UserProfile;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting user by email:', error);
    return null;
  }
}

/**
 * Update user permissions (admin only)
 */
export async function updateUserPermissions(
  uid: string,
  permissions: UserProfile['permissions']
): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    await updateDoc(userRef, {
      permissions,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating user permissions:', error);
    throw error;
  }
}

/**
 * Deactivate user account
 */
export async function deactivateUser(uid: string): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    await updateDoc(userRef, {
      isActive: false,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error deactivating user:', error);
    throw error;
  }
}

/**
 * Reactivate user account
 */
export async function reactivateUser(uid: string): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, uid);
    await updateDoc(userRef, {
      isActive: true,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error reactivating user:', error);
    throw error;
  }
}

// Student interfaces
export interface StudentBasicInfo {
  firstName: string;
  middleName?: string;
  lastName: string;
  gender: "Male" | "Female" | "Other";
  dateOfBirth: string;
  bloodGroup?: string;
  category: string;
  nationality: string;
  religion?: string;
  motherTongue: string;
  caste?: string;
  placeOfBirth?: string;
}

export interface ParentInfo {
  name: string;
  occupation?: string;
  mobile: string;
  email?: string;
  aadharNumber?: string;
  officeAddress?: string;
}

export interface AddressInfo {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  distanceFromSchool?: number;
}

export interface AcademicInfo {
  currentYear: string;
  admissionClass: string;
  section: string;
  rollNumber?: string;
  previousSchool?: {
    name: string;
    lastClass: string;
    percentage?: number;
    board: string;
    transferCertificate?: {
      number: string;
      issueDate: string;
    };
  };
}

export interface DocumentInfo {
  driveId: string;
  url: string;
  fileName: string;
  size: number;
  uploadedAt: string;
  uploadedBy?: string;
}

export interface StudentFeeStructure {
  admissionFee: number;
  tuitionFee: number;
  annualCharges: number;
  transportFee: number;
  cautionDeposit: number;
  computerLabFee: number;
  libraryFee: number;
  examinationFee: number;
  otherCharges: number;
}

export interface Student {
  id: string;
  admissionNumber: string;
  admissionDate: string;
  basic: StudentBasicInfo;
  father?: ParentInfo;
  mother?: ParentInfo;
  guardian?: {
    name: string;
    relation: string;
    mobile: string;
    address?: string;
  };
  primaryContact: "father" | "mother" | "guardian";
  permanentAddress?: AddressInfo;
  currentAddress?: AddressInfo;
  academic: AcademicInfo;
  documents?: {
    photo?: DocumentInfo;
    birthCertificate?: DocumentInfo;
    aadharStudent?: DocumentInfo;
    aadharFather?: DocumentInfo;
    aadharMother?: DocumentInfo;
    transferCertificate?: DocumentInfo;
    previousMarksheet?: DocumentInfo;
    casteCertificate?: DocumentInfo;
    incomeCertificate?: DocumentInfo;
    medicalCertificate?: DocumentInfo;
    addressProof?: DocumentInfo;
  };
  fees?: {
    structure: StudentFeeStructure;
    totalFee: number;
    amountPaid: number;
    balanceDue: number;
    paymentStatus: "paid" | "partial" | "pending" | "overdue";
    paymentHistory?: Array<{
      transactionId: string;
      amount: number;
      paymentMode: string;
      paymentDate: string;
      receiptNumber: string;
    }>;
  };
  status: "draft" | "active" | "inactive" | "alumni";
  createdAt: any;
  updatedAt: any;
}

export interface Settings {
  driveApiKey?: string;
  driveFolderId?: string;
  driveClientId?: string;
  autoBackup?: boolean;
  autosaveDraft?: boolean;
  lastUpdated?: any;
}

// Audit log interface
export interface AuditLog {
  id?: string;
  action: string;
  resourceType: string;
  resourceId: string;
  userId: string;
  userEmail?: string;
  details?: any;
  timestamp: any;
  ipAddress?: string;
  userAgent?: string;
}

// Create audit log entry
export async function createAuditLog(logData: Omit<AuditLog, 'id' | 'timestamp'>): Promise<void> {
  try {
    const auditLogEntry = {
      ...logData,
      timestamp: serverTimestamp(),
      userEmail: auth.currentUser?.email || 'unknown',
    };
    
    await addDoc(collection(db, "auditLogs"), auditLogEntry);
  } catch (error) {
    console.error('Error creating audit log:', error);
    // Don't throw error for audit log failures to avoid breaking main operations
  }
}

// Generate student admission number
export async function generateAdmissionNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const studentsRef = collection(db, "students");
  const q = query(studentsRef, orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  
  const count = snapshot.size + 1;
  const paddedCount = String(count).padStart(5, "0");
  
  return `STU-${year}-${paddedCount}`;
}

// Create a new student (draft or complete)
export async function createStudent(studentData: Partial<Student>): Promise<string> {
  try {
    // Validate required fields
    if (!studentData.basic?.firstName || !studentData.basic?.lastName) {
      throw new Error('Student first name and last name are required');
    }
    
    if (!studentData.academic?.currentYear || !studentData.academic?.admissionClass || !studentData.academic?.section) {
      throw new Error('Academic information (year, class, section) is required');
    }

    // Get current user from Firebase Auth
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to create students');
    }

    const admissionNumber = await generateAdmissionNumber();
    
    // Helper function to recursively filter out undefined values
    const filterUndefined = (obj: any): any => {
      if (obj === null || obj === undefined) {
        return null;
      }
      
      if (Array.isArray(obj)) {
        return obj.map(filterUndefined).filter(item => item !== null && item !== undefined);
      }
      
      if (typeof obj === 'object') {
        const filtered: any = {};
        for (const [key, value] of Object.entries(obj)) {
          if (value !== undefined) {
            const filteredValue = filterUndefined(value);
            if (filteredValue !== null && filteredValue !== undefined) {
              filtered[key] = filteredValue;
            }
          }
        }
        return filtered;
      }
      
      return obj;
    };
    
    // Filter out undefined values from the entire student data
    const cleanStudentData = filterUndefined(studentData);
    
    const newStudent = {
      ...cleanStudentData,
      admissionNumber,
      admissionDate: studentData.admissionDate || new Date().toISOString(),
      status: studentData.status || "draft",
      // Authentication metadata
      createdBy: currentUser.uid,
      updatedBy: currentUser.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      // School context
      schoolId: localStorage.getItem('school_id') || 'default',
      academicYear: studentData.academic?.currentYear || new Date().getFullYear() + '-' + (new Date().getFullYear() + 1),
    };
    
    const docRef = await addDoc(collection(db, "students"), newStudent);
    
    // Create audit log entry
    await createAuditLog({
      action: 'CREATE_STUDENT',
      resourceType: 'student',
      resourceId: docRef.id,
      userId: currentUser.uid,
      details: {
        admissionNumber,
        studentName: `${studentData.basic.firstName} ${studentData.basic.lastName}`,
        class: studentData.academic.admissionClass,
        section: studentData.academic.section
      }
    });
    
    return docRef.id;
  } catch (error) {
    console.error('Error creating student:', error);
    throw error;
  }
}

// Update student data
export async function updateStudent(
  studentId: string,
  updates: Partial<Student>
): Promise<void> {
  try {
    if (!studentId) {
      throw new Error('Student ID is required');
    }

    // Get current user from Firebase Auth
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to update students');
    }

    // Filter out undefined values
    const cleanUpdates = Object.entries(updates).reduce((acc, [key, value]) => {
      if (value !== undefined) {
        acc[key] = value;
      }
      return acc;
    }, {} as any);

    const studentRef = doc(db, "students", studentId);
    
    // Get current student data for audit log
    const currentStudent = await getDoc(studentRef);
    const currentData = currentStudent.data();
    
    await updateDoc(studentRef, {
      ...cleanUpdates,
      updatedBy: currentUser.uid,
      updatedAt: serverTimestamp(),
    });

    // Create audit log entry
    await createAuditLog({
      action: 'UPDATE_STUDENT',
      resourceType: 'student',
      resourceId: studentId,
      userId: currentUser.uid,
      details: {
        studentName: currentData ? `${currentData.basic?.firstName} ${currentData.basic?.lastName}` : 'Unknown',
        updatedFields: Object.keys(cleanUpdates),
        changes: cleanUpdates
      }
    });
  } catch (error) {
    console.error('Error updating student:', error);
    throw error;
  }
}

// Delete student
export async function deleteStudent(studentId: string): Promise<void> {
  try {
    if (!studentId) {
      throw new Error('Student ID is required');
    }

    // Get current user from Firebase Auth
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to delete students');
    }

    const studentRef = doc(db, "students", studentId);
    
    // Get student data before deletion for audit log
    const studentDoc = await getDoc(studentRef);
    const studentData = studentDoc.data();
    
    if (!studentDoc.exists()) {
      throw new Error('Student not found');
    }

    await deleteDoc(studentRef);

    // Create audit log entry
    await createAuditLog({
      action: 'DELETE_STUDENT',
      resourceType: 'student',
      resourceId: studentId,
      userId: currentUser.uid,
      details: {
        studentName: studentData ? `${studentData.basic?.firstName} ${studentData.basic?.lastName}` : 'Unknown',
        admissionNumber: studentData?.admissionNumber,
        class: studentData?.academic?.admissionClass,
        section: studentData?.academic?.section
      }
    });
  } catch (error) {
    console.error('Error deleting student:', error);
    throw error;
  }
}

// Get single student
export async function getStudent(studentId: string): Promise<Student | null> {
  try {
    if (!studentId) {
      throw new Error('Student ID is required');
    }

    const studentRef = doc(db, "students", studentId);
    const snapshot = await getDoc(studentRef);
    
    if (snapshot.exists()) {
      const data = snapshot.data();
      return { 
        id: snapshot.id, 
        ...data,
        // Convert Firestore timestamps to dates for consistency
        createdAt: data.createdAt?.toDate?.() || data.createdAt,
        updatedAt: data.updatedAt?.toDate?.() || data.updatedAt,
      } as Student;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting student:', error);
    throw error;
  }
}

// Get all students (with optional filters)
export async function getStudents(filters?: {
  class?: string;
  section?: string;
  status?: string;
}): Promise<Student[]> {
  try {
    let q = query(collection(db, "students"), orderBy("createdAt", "desc"));
    
    if (filters?.class) {
      q = query(q, where("academic.admissionClass", "==", filters.class));
    }
    
    if (filters?.section) {
      q = query(q, where("academic.section", "==", filters.section));
    }
    
    if (filters?.status) {
      q = query(q, where("status", "==", filters.status));
    }
    
    const snapshot = await getDocs(q);
    return snapshot.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        // Convert Firestore timestamps to dates for consistency
        createdAt: data.createdAt?.toDate?.() || data.createdAt,
        updatedAt: data.updatedAt?.toDate?.() || data.updatedAt,
      } as Student;
    });
  } catch (error) {
    console.error('Error getting students:', error);
    throw error;
  }
}

// Real-time listener for students with enhanced error handling
export function subscribeToStudents(
  callback: (students: Student[]) => void,
  filters?: { class?: string; section?: string; status?: string }
): () => void {
  try {
    let q = query(collection(db, "students"), orderBy("createdAt", "desc"));
    
    if (filters?.class) {
      q = query(q, where("academic.admissionClass", "==", filters.class));
    }
    
    if (filters?.section) {
      q = query(q, where("academic.section", "==", filters.section));
    }
    
    if (filters?.status) {
      q = query(q, where("status", "==", filters.status));
    }
    
    return onSnapshot(q, 
      (snapshot) => {
        const students = snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            ...data,
            // Convert Firestore timestamps to dates for consistency
            createdAt: data.createdAt?.toDate?.() || data.createdAt,
            updatedAt: data.updatedAt?.toDate?.() || data.updatedAt,
          } as Student;
        });
        callback(students);
      },
      (error) => {
        console.error('Error in students subscription:', error);
        // Call callback with empty array on error to prevent UI crashes
        callback([]);
      }
    );
  } catch (error) {
    console.error('Error setting up students subscription:', error);
    // Return a no-op unsubscribe function
    return () => {};
  }
}

// Bulk operations for students
export async function bulkUpdateStudents(
  studentIds: string[],
  updates: Partial<Student>
): Promise<void> {
  try {
    if (!studentIds.length) {
      throw new Error('No student IDs provided');
    }

    // Filter out undefined values
    const cleanUpdates = Object.entries(updates).reduce((acc, [key, value]) => {
      if (value !== undefined) {
        acc[key] = value;
      }
      return acc;
    }, {} as any);

    const updatePromises = studentIds.map(id => 
      updateStudent(id, { ...cleanUpdates, updatedAt: serverTimestamp() })
    );
    
    await Promise.all(updatePromises);
  } catch (error) {
    console.error('Error bulk updating students:', error);
    throw error;
  }
}

export async function bulkDeleteStudents(studentIds: string[]): Promise<void> {
  try {
    if (!studentIds.length) {
      throw new Error('No student IDs provided');
    }

    const deletePromises = studentIds.map(id => deleteStudent(id));
    await Promise.all(deletePromises);
  } catch (error) {
    console.error('Error bulk deleting students:', error);
    throw error;
  }
}

// Admission Management Functions

export interface AdmissionProcess {
  id?: string;
  status: 'draft' | 'in_progress' | 'completed' | 'cancelled';
  currentStep: number;
  totalSteps: number;
  studentData?: Partial<Student>;
  createdBy: string;
  updatedBy?: string;
  createdAt: any;
  updatedAt: any;
  completedAt?: any;
  schoolId?: string;
  academicYear: string;
}

export interface AdmissionStep {
  stepNumber: number;
  stepName: string;
  data: any;
  isCompleted: boolean;
  completedAt?: any;
  completedBy?: string;
  validationErrors?: string[];
}

// Create new admission process
export async function createAdmissionProcess(academicYear?: string): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to create admission process');
    }

    const admissionData: Omit<AdmissionProcess, 'id'> = {
      status: 'draft',
      currentStep: 1,
      totalSteps: 7,
      createdBy: currentUser.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      schoolId: localStorage.getItem('school_id') || 'default',
      academicYear: academicYear || `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`
    };

    const docRef = await addDoc(collection(db, "admissions"), admissionData);
    
    // Create audit log
    await createAuditLog({
      action: 'CREATE_ADMISSION_PROCESS',
      resourceType: 'admission',
      resourceId: docRef.id,
      userId: currentUser.uid,
      details: { academicYear: admissionData.academicYear }
    });

    return docRef.id;
  } catch (error) {
    console.error('Error creating admission process:', error);
    throw error;
  }
}

// Update admission step
export async function updateAdmissionStep(
  admissionId: string,
  stepNumber: number,
  stepData: any,
  isCompleted: boolean = false
): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to update admission steps');
    }

    // Update the step document
    const stepRef = doc(db, "admissions", admissionId, "steps", stepNumber.toString());
    const stepDoc: AdmissionStep = {
      stepNumber,
      stepName: getStepName(stepNumber),
      data: stepData,
      isCompleted,
      completedBy: currentUser.uid,
      ...(isCompleted && { completedAt: serverTimestamp() })
    };

    await setDoc(stepRef, stepDoc, { merge: true });

    // Update the main admission document
    const admissionRef = doc(db, "admissions", admissionId);
    const updateData: any = {
      updatedBy: currentUser.uid,
      updatedAt: serverTimestamp(),
    };

    if (isCompleted) {
      updateData.currentStep = Math.min(stepNumber + 1, 7);
      
      // Check if all steps are completed
      if (stepNumber === 7) {
        updateData.status = 'completed';
        updateData.completedAt = serverTimestamp();
      } else {
        updateData.status = 'in_progress';
      }
    }

    await updateDoc(admissionRef, updateData);

    // Create audit log
    await createAuditLog({
      action: 'UPDATE_ADMISSION_STEP',
      resourceType: 'admission',
      resourceId: admissionId,
      userId: currentUser.uid,
      details: {
        stepNumber,
        stepName: getStepName(stepNumber),
        isCompleted
      }
    });
  } catch (error) {
    console.error('Error updating admission step:', error);
    throw error;
  }
}

// Get admission process
export async function getAdmissionProcess(admissionId: string): Promise<AdmissionProcess | null> {
  try {
    const admissionRef = doc(db, "admissions", admissionId);
    const admissionSnap = await getDoc(admissionRef);
    
    if (admissionSnap.exists()) {
      const data = admissionSnap.data();
      return {
        id: admissionSnap.id,
        ...data,
        createdAt: data.createdAt?.toDate?.() || data.createdAt,
        updatedAt: data.updatedAt?.toDate?.() || data.updatedAt,
        completedAt: data.completedAt?.toDate?.() || data.completedAt,
      } as AdmissionProcess;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting admission process:', error);
    throw error;
  }
}

// Update admission process
export async function updateAdmissionProcess(admissionId: string, data: Partial<AdmissionProcess>): Promise<void> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to update admission');
    }

    const admissionRef = doc(db, "admissions", admissionId);
    await updateDoc(admissionRef, {
      ...data,
      updatedBy: currentUser.uid,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating admission process:', error);
    throw error;
  }
}

// Get admission step data
export async function getAdmissionStep(admissionId: string, stepNumber: number): Promise<AdmissionStep | null> {
  try {
    const stepRef = doc(db, "admissions", admissionId, "steps", stepNumber.toString());
    const stepSnap = await getDoc(stepRef);
    
    if (stepSnap.exists()) {
      const data = stepSnap.data();
      return {
        ...data,
        completedAt: data.completedAt?.toDate?.() || data.completedAt,
      } as AdmissionStep;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting admission step:', error);
    throw error;
  }
}

// Complete admission process and create student record
export async function completeAdmissionProcess(admissionId: string): Promise<string> {
  try {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('User must be authenticated to complete admission');
    }

    // Get admission process data
    const admission = await getAdmissionProcess(admissionId);
    if (!admission) {
      throw new Error('Admission process not found');
    }

    // Collect all step data
    const allStepData: any = {};
    for (let i = 1; i <= 7; i++) {
      const stepData = await getAdmissionStep(admissionId, i);
      if (stepData) {
        allStepData[`step${i}`] = stepData.data;
      }
    }

    // Create complete student record
    const studentData = mergeAdmissionStepsToStudent(allStepData);
    const studentId = await createStudent(studentData);

    // Update admission process as completed
    const admissionRef = doc(db, "admissions", admissionId);
    await updateDoc(admissionRef, {
      status: 'completed',
      studentId,
      completedAt: serverTimestamp(),
      updatedBy: currentUser.uid,
      updatedAt: serverTimestamp()
    });

    // Create audit log
    await createAuditLog({
      action: 'COMPLETE_ADMISSION',
      resourceType: 'admission',
      resourceId: admissionId,
      userId: currentUser.uid,
      details: {
        studentId,
        studentName: `${studentData.basic?.firstName} ${studentData.basic?.lastName}`
      }
    });

    return studentId;
  } catch (error) {
    console.error('Error completing admission process:', error);
    throw error;
  }
}

// Helper function to get step name
function getStepName(stepNumber: number): string {
  const stepNames = [
    '', // 0 index
    'Basic Information',
    'Parent & Guardian Information', 
    'Address Information',
    'Academic History',
    'Document Upload',
    'Fee Structure Setup',
    'Review & Confirmation'
  ];
  return stepNames[stepNumber] || 'Unknown Step';
}

// Helper function to merge admission steps into student data
function mergeAdmissionStepsToStudent(stepData: any): Partial<Student> {
  return {
    basic: stepData.step1?.basic,
    father: stepData.step2?.father,
    mother: stepData.step2?.mother,
    guardian: stepData.step2?.guardian,
    primaryContact: stepData.step2?.primaryContact,
    permanentAddress: stepData.step3?.permanentAddress,
    currentAddress: stepData.step3?.currentAddress,
    academic: {
      ...stepData.step1?.academic,
      ...stepData.step4?.academic
    },
    documents: stepData.step5?.documents,
    fees: stepData.step6?.fees,
    status: 'active'
  };
}
export async function searchStudents(searchTerm: string, filters?: {
  class?: string;
  section?: string;
  status?: string;
}): Promise<Student[]> {
  try {
    // Get all students first (Firestore doesn't support full-text search natively)
    const students = await getStudents(filters);
    
    if (!searchTerm.trim()) {
      return students;
    }
    
    const term = searchTerm.toLowerCase();
    
    return students.filter(student => {
      const fullName = `${student.basic.firstName} ${student.basic.middleName || ""} ${student.basic.lastName}`.toLowerCase();
      const admissionNumber = student.admissionNumber.toLowerCase();
      const rollNumber = student.academic.rollNumber?.toLowerCase() || "";
      
      return fullName.includes(term) || 
             admissionNumber.includes(term) || 
             rollNumber.includes(term);
    });
  } catch (error) {
    console.error('Error searching students:', error);
    throw error;
  }
}

// Teacher interfaces
export interface TeacherPersonalInfo {
  firstName: string;
  middleName?: string;
  lastName: string;
  gender: "Male" | "Female" | "Other";
  dateOfBirth: string;
  aadharNumber?: string;
  panNumber?: string;
  bloodGroup?: string;
  religion?: string;
  category: string;
  maritalStatus?: string;
  nationality: string;
  profilePhotoUrl?: string;
}

export interface TeacherContactInfo {
  mobile: string;
  alternateMobile?: string;
  email?: string;
  residentialAddress: AddressInfo;
  permanentAddress?: AddressInfo;
  emergencyContact?: {
    name: string;
    relation: string;
    mobile: string;
  };
}

export interface TeacherQualification {
  highestQualification: string;
  additionalQualifications?: string[];
  yearsOfExperience: number;
  previousSchool?: string;
  subjectExpertise: string[];
  certificates?: DocumentInfo[];
}

export interface TeacherEmployment {
  dateOfJoining: string;
  department: string;
  designation: string;
  employeeType: "Permanent" | "Contract" | "Visiting";
  classResponsibilities?: string[];
  workingShift?: "Morning" | "Evening" | "Both";
  assignedSubjects: string[];
  salary: {
    basic: number;
    hra: number;
    allowances: number;
    deductions: number;
    netSalary: number;
  };
}

export interface Teacher {
  id: string;
  teacherId: string;
  personal: TeacherPersonalInfo;
  contact: TeacherContactInfo;
  qualification: TeacherQualification;
  employment: TeacherEmployment;
  documents?: {
    aadharCard?: DocumentInfo;
    panCard?: DocumentInfo;
    educationalCertificates?: DocumentInfo[];
    experienceLetters?: DocumentInfo[];
    joiningLetter?: DocumentInfo;
    addressProof?: DocumentInfo;
    bankPassbook?: DocumentInfo;
  };
  driveFolderId?: string;
  status: "Active" | "On Leave" | "Resigned";
  createdAt: any;
  updatedAt: any;
}

// Generate teacher ID
export async function generateTeacherId(): Promise<string> {
  const year = new Date().getFullYear();
  const teachersRef = collection(db, "teachers");
  const q = query(teachersRef, orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  
  const count = snapshot.size + 1;
  const paddedCount = String(count).padStart(4, "0");
  
  return `TCH-${year}-${paddedCount}`;
}

// Create a new teacher
export async function createTeacher(teacherData: Partial<Teacher>): Promise<string> {
  const teacherId = await generateTeacherId();
  
  const newTeacher = {
    ...teacherData,
    teacherId,
    status: teacherData.status || "Active",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  
  const docRef = await addDoc(collection(db, "teachers"), newTeacher);
  return docRef.id;
}

// Update teacher data
export async function updateTeacher(
  teacherId: string,
  updates: Partial<Teacher>
): Promise<void> {
  const teacherRef = doc(db, "teachers", teacherId);
  await updateDoc(teacherRef, {
    ...updates,
    updatedAt: serverTimestamp(),
  });
}

// Delete teacher
export async function deleteTeacher(teacherId: string): Promise<void> {
  const teacherRef = doc(db, "teachers", teacherId);
  await deleteDoc(teacherRef);
}

// Get single teacher
export async function getTeacher(teacherId: string): Promise<Teacher | null> {
  const teacherRef = doc(db, "teachers", teacherId);
  const snapshot = await getDoc(teacherRef);
  
  if (snapshot.exists()) {
    return { id: snapshot.id, ...snapshot.data() } as Teacher;
  }
  
  return null;
}

// Get all teachers with optional filters
export async function getTeachers(filters?: {
  department?: string;
  status?: string;
  designation?: string;
}): Promise<Teacher[]> {
  let q = query(collection(db, "teachers"), orderBy("createdAt", "desc"));
  
  if (filters?.department) {
    q = query(q, where("employment.department", "==", filters.department));
  }
  
  if (filters?.status) {
    q = query(q, where("status", "==", filters.status));
  }
  
  if (filters?.designation) {
    q = query(q, where("employment.designation", "==", filters.designation));
  }
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Teacher));
}

// Real-time listener for teachers
export function subscribeToTeachers(
  callback: (teachers: Teacher[]) => void,
  filters?: { department?: string; status?: string; designation?: string }
): () => void {
  let q = query(collection(db, "teachers"), orderBy("createdAt", "desc"));
  
  if (filters?.department) {
    q = query(q, where("employment.department", "==", filters.department));
  }
  
  if (filters?.status) {
    q = query(q, where("status", "==", filters.status));
  }
  
  if (filters?.designation) {
    q = query(q, where("employment.designation", "==", filters.designation));
  }
  
  return onSnapshot(q, (snapshot) => {
    const teachers = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Teacher[];
    callback(teachers);
  });
}

// Fee Structure interfaces
export interface FeeStructure {
  id: string;
  structureId: string;
  className: string;
  academicYear: string;
  admissionFee: number;
  tuitionFee: number;
  transportFee: number;
  labFee: number;
  examFee: number;
  otherCharges: number;
  totalAnnual: number;
  createdAt: any;
  updatedAt: any;
}

export interface FeeDetails {
  structureId: string;
  admissionFee: number;
  tuitionFee: number;
  transportFee: number;
  labFee: number;
  examFee: number;
  otherCharges: number;
  totalDue: number;
  totalPaid: number;
  balance: number;
  lastPaymentDate: string | null;
  paymentStatus: "Paid" | "Partial" | "Pending" | "Overdue";
  dueDate: string;
  remarks: string;
}

export interface FeeTransaction {
  id: string;
  transactionId: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  className: string;
  section: string;
  amountPaid: number;
  totalDueBefore: number;
  balanceAfter: number;
  paymentMode: "Cash" | "Cheque" | "UPI" | "Bank Transfer" | "Online";
  transactionRef?: string;
  paymentDate: string;
  receiptDriveLink?: string;
  receiptFileName?: string;
  remarks?: string;
  createdAt: any;
  createdBy: string;
}

// Generate fee structure ID
export async function generateFeeStructureId(): Promise<string> {
  const year = new Date().getFullYear();
  const structuresRef = collection(db, "feeStructures");
  const q = query(structuresRef, orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  
  const count = snapshot.size + 1;
  const paddedCount = String(count).padStart(4, "0");
  
  return `FS-${year}-${paddedCount}`;
}

// Generate transaction ID
export async function generateTransactionId(): Promise<string> {
  const year = new Date().getFullYear();
  const transactionsRef = collection(db, "feesTransactions");
  const q = query(transactionsRef, orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  
  const count = snapshot.size + 1;
  const paddedCount = String(count).padStart(5, "0");
  
  return `TXN-${year}-${paddedCount}`;
}

// Create fee structure
export async function createFeeStructure(structureData: Partial<FeeStructure>): Promise<string> {
  const structureId = await generateFeeStructureId();
  
  const newStructure = {
    ...structureData,
    structureId,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  
  const docRef = await addDoc(collection(db, "feeStructures"), newStructure);
  return docRef.id;
}

// Update fee structure
export async function updateFeeStructure(
  structureId: string,
  updates: Partial<FeeStructure>
): Promise<void> {
  const structureRef = doc(db, "feeStructures", structureId);
  await updateDoc(structureRef, {
    ...updates,
    updatedAt: serverTimestamp(),
  });
}

// Delete fee structure
export async function deleteFeeStructure(structureId: string): Promise<void> {
  const structureRef = doc(db, "feeStructures", structureId);
  await deleteDoc(structureRef);
}

// Get all fee structures
export async function getFeeStructures(): Promise<FeeStructure[]> {
  const q = query(collection(db, "feeStructures"), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as FeeStructure));
}

// Subscribe to fee structures
export function subscribeToFeeStructures(
  callback: (structures: FeeStructure[]) => void
): () => void {
  const q = query(collection(db, "feeStructures"), orderBy("createdAt", "desc"));
  
  return onSnapshot(q, (snapshot) => {
    const structures = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as FeeStructure[];
    callback(structures);
  });
}

// Create fee transaction
export async function createFeeTransaction(
  transactionData: Partial<FeeTransaction>
): Promise<string> {
  const transactionId = await generateTransactionId();
  
  const newTransaction = {
    ...transactionData,
    transactionId,
    createdAt: serverTimestamp(),
  };
  
  // Add to global transactions collection
  const docRef = await addDoc(collection(db, "feesTransactions"), newTransaction);
  
  // Also add to student's transactions subcollection
  if (transactionData.studentId) {
    const studentTransactionsRef = collection(
      db,
      `students/${transactionData.studentId}/feesTransactions`
    );
    await addDoc(studentTransactionsRef, newTransaction);
  }
  
  return docRef.id;
}

// Get all fee transactions
export async function getFeeTransactions(filters?: {
  startDate?: string;
  endDate?: string;
  studentId?: string;
  className?: string;
}): Promise<FeeTransaction[]> {
  let q = query(collection(db, "feesTransactions"), orderBy("createdAt", "desc"));
  
  if (filters?.studentId) {
    q = query(q, where("studentId", "==", filters.studentId));
  }
  
  if (filters?.className) {
    q = query(q, where("className", "==", filters.className));
  }
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as FeeTransaction));
}

// Subscribe to fee transactions
export function subscribeToFeeTransactions(
  callback: (transactions: FeeTransaction[]) => void,
  filters?: { studentId?: string; className?: string }
): () => void {
  let q = query(collection(db, "feesTransactions"), orderBy("createdAt", "desc"));
  
  if (filters?.studentId) {
    q = query(q, where("studentId", "==", filters.studentId));
  }
  
  if (filters?.className) {
    q = query(q, where("className", "==", filters.className));
  }
  
  return onSnapshot(q, (snapshot) => {
    const transactions = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as FeeTransaction[];
    callback(transactions);
  });
}

// Get student fee details
export async function getStudentFeeDetails(studentId: string): Promise<FeeDetails | null> {
  const feeDetailsRef = doc(db, `students/${studentId}/feeDetails`, "current");
  const snapshot = await getDoc(feeDetailsRef);
  
  if (snapshot.exists()) {
    return snapshot.data() as FeeDetails;
  }
  
  return null;
}

// Update student fee details
export async function updateStudentFeeDetails(
  studentId: string,
  feeDetails: Partial<FeeDetails>
): Promise<void> {
  const feeDetailsRef = doc(db, `students/${studentId}/feeDetails`, "current");
  
  try {
    await updateDoc(feeDetailsRef, feeDetails);
  } catch (error) {
    // If document doesn't exist, create it
    await addDoc(collection(db, `students/${studentId}/feeDetails`), feeDetails);
  }
}

// Assign fee structure to student
export async function assignFeeStructureToStudent(
  studentId: string,
  structureId: string,
  structure: FeeStructure,
  dueDate: string
): Promise<void> {
  const feeDetails: FeeDetails = {
    structureId: structureId,
    admissionFee: structure.admissionFee,
    tuitionFee: structure.tuitionFee,
    transportFee: structure.transportFee,
    labFee: structure.labFee,
    examFee: structure.examFee,
    otherCharges: structure.otherCharges,
    totalDue: structure.totalAnnual,
    totalPaid: 0,
    balance: structure.totalAnnual,
    lastPaymentDate: null,
    paymentStatus: "Pending",
    dueDate: dueDate,
    remarks: "",
  };
  
  const feeDetailsRef = doc(db, `students/${studentId}/feeDetails`, "current");
  await updateDoc(feeDetailsRef, feeDetails as any).catch(async () => {
    // If document doesn't exist, create it using setDoc
    await setDoc(feeDetailsRef, feeDetails);
  });
}

// Settings operations
export async function getSettings(adminId: string): Promise<Settings | null> {
  const settingsRef = doc(db, "settings", adminId);
  const snapshot = await getDoc(settingsRef);
  
  if (snapshot.exists()) {
    return snapshot.data() as Settings;
  }
  
  return null;
}

export async function saveSettings(
  adminId: string,
  settings: Settings
): Promise<void> {
  const settingsRef = doc(db, "settings", adminId);
  await updateDoc(settingsRef, {
    ...settings,
    lastUpdated: serverTimestamp(),
  }).catch(async () => {
    // If document doesn't exist, create it
    await addDoc(collection(db, "settings"), {
      ...settings,
      lastUpdated: serverTimestamp(),
    });
  });
}

// Attendance interfaces
export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  className: string;
  section: string;
  date: string;
  status: "Present" | "Absent" | "Late" | "Leave";
  remarks?: string;
  markedBy: string;
  timestamp: any;
}

export interface AttendanceDocument {
  id: string;
  fileName: string;
  fileId: string;
  uploadedBy: string;
  uploadedAt: any;
  fileUrl: string;
}

// Mark attendance for students
export async function markAttendance(
  academicYear: string,
  className: string,
  section: string,
  date: string,
  attendanceRecords: Omit<AttendanceRecord, "id" | "timestamp">[]
): Promise<void> {
  const batch: Promise<void>[] = [];
  
  attendanceRecords.forEach((record) => {
    const attendanceRef = doc(
      db,
      `attendance/${academicYear}/${className}_${section}/${date}`,
      record.studentId
    );
    
    batch.push(
      setDoc(attendanceRef, {
        ...record,
        timestamp: serverTimestamp(),
      })
    );
  });
  
  await Promise.all(batch);
}

// Get attendance for a specific date and class
export async function getAttendanceByDate(
  academicYear: string,
  className: string,
  section: string,
  date: string
): Promise<AttendanceRecord[]> {
  const attendanceRef = collection(
    db,
    `attendance/${academicYear}/${className}_${section}/${date}`
  );
  const snapshot = await getDocs(attendanceRef);
  
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  })) as AttendanceRecord[];
}

// Get attendance for a student
export async function getStudentAttendance(
  studentId: string,
  startDate?: string,
  endDate?: string
): Promise<AttendanceRecord[]> {
  // Note: This is a simplified version. In production, you'd need to query across multiple dates
  // For now, we'll query the global attendance collection if it exists
  const attendanceRef = collection(db, "studentAttendance");
  let q = query(attendanceRef, where("studentId", "==", studentId), orderBy("date", "desc"));
  
  if (startDate) {
    q = query(q, where("date", ">=", startDate));
  }
  
  if (endDate) {
    q = query(q, where("date", "<=", endDate));
  }
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  })) as AttendanceRecord[];
}

// Subscribe to attendance records
export function subscribeToAttendance(
  academicYear: string,
  className: string,
  section: string,
  date: string,
  callback: (records: AttendanceRecord[]) => void
): () => void {
  const attendanceRef = collection(
    db,
    `attendance/${academicYear}/${className}_${section}/${date}`
  );
  
  return onSnapshot(attendanceRef, (snapshot) => {
    const records = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as AttendanceRecord[];
    callback(records);
  });
}

// Get attendance summary for a class
export async function getAttendanceSummary(
  academicYear: string,
  className: string,
  section: string,
  startDate: string,
  endDate: string
): Promise<{
  totalDays: number;
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  totalLeave: number;
}> {
  // This would need to aggregate across multiple dates
  // Simplified version for now
  return {
    totalDays: 0,
    totalPresent: 0,
    totalAbsent: 0,
    totalLate: 0,
    totalLeave: 0,
  };
}

// Upload attendance document
export async function uploadAttendanceDocument(
  academicYear: string,
  className: string,
  section: string,
  date: string,
  documentData: Omit<AttendanceDocument, "id">
): Promise<string> {
  const docRef = await addDoc(
    collection(db, `attendance/${academicYear}/${className}_${section}/${date}/documents`),
    {
      ...documentData,
      uploadedAt: serverTimestamp(),
    }
  );
  
  return docRef.id;
}
