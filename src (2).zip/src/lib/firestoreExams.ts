import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  setDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  Timestamp,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "./firebase";

// ============= EXAMS & MARKS INTERFACES =============

export interface ExamType {
  id: string;
  name: string;
  type: "Unit Test" | "Midterm" | "Final" | "Custom";
  totalMarks: number;
  dateRange: {
    start: string;
    end: string;
  };
  academicYear: string;
  classId: string;
  subjects: string[]; // Subject IDs
  createdBy?: string;
  createdAt: string;
}

export interface SubjectMarks {
  subjectId: string;
  subjectName: string;
  marksObtained: number;
  totalMarks: number;
  grade: string;
  percentage: number;
}

export interface StudentMarks {
  id: string;
  examId: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  classId: string;
  section: string;
  academicYear: string;
  subjects: SubjectMarks[];
  totalMarksObtained: number;
  totalMaxMarks: number;
  percentage: number;
  overallGrade: string;
  remarks?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PerformanceReport {
  id: string;
  studentId: string;
  examId: string;
  driveLink?: string;
  generatedAt: string;
  fileName: string;
}

// ============= UTILITY FUNCTIONS =============

export function calculateGrade(percentage: number): string {
  if (percentage >= 90) return "A+";
  if (percentage >= 80) return "A";
  if (percentage >= 70) return "B+";
  if (percentage >= 60) return "B";
  if (percentage >= 50) return "C";
  if (percentage >= 35) return "D";
  return "F";
}

export function generateExamId(): string {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 1000);
  return `EXM${timestamp}${random}`;
}

// ============= EXAM CRUD OPERATIONS =============

export async function createExam(examData: Omit<ExamType, "id" | "createdAt">): Promise<string> {
  const docRef = await addDoc(collection(db, "exams"), {
    ...examData,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function updateExam(examId: string, examData: Partial<ExamType>): Promise<void> {
  const docRef = doc(db, "exams", examId);
  await updateDoc(docRef, {
    ...examData,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteExam(examId: string): Promise<void> {
  const docRef = doc(db, "exams", examId);
  await deleteDoc(docRef);
}

export async function getExam(examId: string): Promise<ExamType | null> {
  const docRef = doc(db, "exams", examId);
  const docSnap = await getDoc(docRef);
  
  if (docSnap.exists()) {
    return { id: docSnap.id, ...docSnap.data() } as ExamType;
  }
  return null;
}

export async function getExams(filters?: {
  academicYear?: string;
  classId?: string;
  type?: string;
}): Promise<ExamType[]> {
  let q = query(collection(db, "exams"), orderBy("createdAt", "desc"));

  if (filters?.academicYear) {
    q = query(q, where("academicYear", "==", filters.academicYear));
  }
  if (filters?.classId) {
    q = query(q, where("classId", "==", filters.classId));
  }
  if (filters?.type) {
    q = query(q, where("type", "==", filters.type));
  }

  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as ExamType));
}

export function subscribeToExams(
  callback: (exams: ExamType[]) => void,
  filters?: { academicYear?: string; classId?: string }
): () => void {
  let q = query(collection(db, "exams"), orderBy("createdAt", "desc"));

  if (filters?.academicYear) {
    q = query(q, where("academicYear", "==", filters.academicYear));
  }
  if (filters?.classId) {
    q = query(q, where("classId", "==", filters.classId));
  }

  return onSnapshot(q, (snapshot) => {
    const exams = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as ExamType));
    callback(exams);
  });
}

// ============= MARKS CRUD OPERATIONS =============

export async function saveStudentMarks(marksData: Omit<StudentMarks, "id" | "createdAt" | "updatedAt">): Promise<string> {
  const docRef = await addDoc(collection(db, "marks"), {
    ...marksData,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function updateStudentMarks(marksId: string, marksData: Partial<StudentMarks>): Promise<void> {
  const docRef = doc(db, "marks", marksId);
  await updateDoc(docRef, {
    ...marksData,
    updatedAt: serverTimestamp(),
  });
}

export async function getStudentMarks(studentId: string, examId: string): Promise<StudentMarks | null> {
  const q = query(
    collection(db, "marks"),
    where("studentId", "==", studentId),
    where("examId", "==", examId)
  );
  
  const snapshot = await getDocs(q);
  if (!snapshot.empty) {
    const doc = snapshot.docs[0];
    return { id: doc.id, ...doc.data() } as StudentMarks;
  }
  return null;
}

export async function getMarksByExam(examId: string): Promise<StudentMarks[]> {
  const q = query(collection(db, "marks"), where("examId", "==", examId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as StudentMarks));
}

export async function getStudentAllMarks(studentId: string): Promise<StudentMarks[]> {
  const q = query(
    collection(db, "marks"),
    where("studentId", "==", studentId),
    orderBy("createdAt", "desc")
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as StudentMarks));
}

export function subscribeToStudentMarks(
  studentId: string,
  callback: (marks: StudentMarks[]) => void
): () => void {
  const q = query(
    collection(db, "marks"),
    where("studentId", "==", studentId),
    orderBy("createdAt", "desc")
  );

  return onSnapshot(q, (snapshot) => {
    const marks = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as StudentMarks));
    callback(marks);
  });
}

// ============= PERFORMANCE REPORTS =============

export async function savePerformanceReport(
  reportData: Omit<PerformanceReport, "id" | "generatedAt">
): Promise<string> {
  const docRef = await addDoc(collection(db, "performanceReports"), {
    ...reportData,
    generatedAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function getStudentReports(studentId: string): Promise<PerformanceReport[]> {
  const q = query(
    collection(db, "performanceReports"),
    where("studentId", "==", studentId),
    orderBy("generatedAt", "desc")
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as PerformanceReport));
}
